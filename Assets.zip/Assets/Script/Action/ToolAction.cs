using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ToolAction : ScriptableObject
{
   public virtual bool OnApply(Vector2 worldPoint){
    Debug.LogWarning("tidak bisa");
    return true;
   }

   public int energyCost = 0;
}

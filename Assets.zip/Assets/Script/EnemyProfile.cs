using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[CreateAssetMenu(menuName = "Enemy/Enemy Profile")]
public class EnemyProfile : ScriptableObject
{
   public string enemyName;
}

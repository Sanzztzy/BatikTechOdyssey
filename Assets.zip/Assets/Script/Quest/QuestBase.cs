using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class QuestBase : ScriptableObject 
{
    public string questName;
    [TextArea(5,10  )]
    public string questDescription;

    public int[] CurrentAmount {get; set;}
    public int[] RequiredAmount{get; set;}

    public bool IsCompleted{get; set;}

    public virtual void InitializeQuest(){
        
        IsCompleted = false;
        CurrentAmount = new int[RequiredAmount.Length];
        QuestLogManager.instance.AddQuest(this);
    }

    public void Evaluate(){

        for(int i = 0; i < RequiredAmount.Length; i++ ){

            if(CurrentAmount[i] < RequiredAmount[i]){

                return;

            }
        }
        IsCompleted = true;
        Debug.Log("complete");
    }   

    public virtual string GetObjectiveList(){

        return " ";
    }
}

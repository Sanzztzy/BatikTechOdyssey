using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Data/Dialogue/Dialogue Quest")]
public class DialogueQuest : DialogueContainer
{
  public QuestBase quest;

}

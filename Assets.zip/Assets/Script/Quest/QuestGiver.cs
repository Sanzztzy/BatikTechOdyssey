using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class QuestGiver : MonoBehaviour
{
    [SerializeField] private Quest[] quest;
    private QuestLog tmpLog;

    private void Start(){     

        tmpLog = FindObjectOfType<QuestLog>();
            if(tmpLog != null){

                tmpLog.AcceptQuest(quest[0]);
                
            }

            else{

                Debug.LogError("QuestLog not found in the scene.");
            }
        
        
    }
}   

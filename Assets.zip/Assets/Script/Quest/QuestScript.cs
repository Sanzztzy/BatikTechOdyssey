using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class QuestScript : MonoBehaviour
{   
    public Quest myQuest{get;set;}

    public void Select(){

        GetComponent<Text>().color = Color.red;    
        QuestLog.myInstance.showDescription(myQuest);
    }

    public void Unselect(){
        
        GetComponent<Text>().color = Color.white;  

    }
}

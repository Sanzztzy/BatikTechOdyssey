using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class QuestTrigger : talkInteract
{
   public bool ActiveQuest;
   public DialogueQuest[] dialogueQuest;
   public int questIndex{get; set;}

   public override void Interact(character Char){

        if(ActiveQuest){

            GameManager.instance.dialogueSystem.Initialize(dialogueQuest[questIndex]);
            QuestManager.instance.currentQuestDialogue = this;
        }
        else{
            base.Interact(Char);
        }
   }
}

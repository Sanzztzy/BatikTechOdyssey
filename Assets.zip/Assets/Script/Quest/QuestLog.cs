using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class QuestLog : MonoBehaviour
{   

    [SerializeField]private GameObject questPrefab;
    [SerializeField]private Transform questParent;
    [SerializeField]private Text questDescription;

    private Quest selected;
    private static QuestLog instance;

    public static QuestLog myInstance
    {
        get{
            if(instance == null){

                instance = FindObjectOfType<QuestLog>();
            }
            return instance;
        }
    }

    private void Awake()
    {
        DontDestroyOnLoad(gameObject);
    }   

    public void AcceptQuest(Quest quest){

        GameObject go = Instantiate(questPrefab, questParent);
        QuestScript qs = go.GetComponent<QuestScript>();
        quest.myQuestScript = qs;
        qs.myQuest = quest;
        go.GetComponent<Text>().text = quest.myTitle;

    }

    public void showDescription(Quest quest){

        if(selected != null){
            selected.myQuestScript.Unselect();
        }

        string objectives = string.Empty;
        selected = quest;
        string title = quest.myTitle;

        foreach(Objective obj in quest.myCollectObjective){

            objectives += obj.myType + ":" + obj.currentAmount+ "/" + obj.myAmount + "\n";
        }
        questDescription.text = string.Format("{0}\n\nObjectives\n{1}", quest.myDescription, objectives);

    }
}

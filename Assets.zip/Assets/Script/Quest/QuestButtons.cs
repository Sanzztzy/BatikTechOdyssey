using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class QuestButtons : MonoBehaviour
{   

    public void Ambil(){
        
        QuestManager.instance.currentQuestDialogue.ActiveQuest = false;
        QuestManager.instance.currentQuest.InitializeQuest();
        QuestManager.instance.questUI.SetActive(false);


        GameManager.instance.UpdateTracker($"You've Accepted {QuestManager.instance.currentQuest.questName}");
        
    }

}

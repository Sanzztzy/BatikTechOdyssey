using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class QuestLogManager : MonoBehaviour
{   
    public static QuestLogManager instance;

    public Text questName;
    public Text questDescription;
    public Transform questHolder;
    public GameObject questButtonPrefab;
    public GameObject questlogUI;
    public Text objectivesText;

    private QuestBase lastDisplay;



    private void Awake(){

        if(instance == null) instance = this;
        
    }

    public void UpdateQuestUI(QuestBase newQuest, string objectiveList){

        lastDisplay = newQuest;
        
        questName.text = newQuest.questName;
        questDescription.text = newQuest.questDescription;
        objectivesText.text = objectiveList;
    }

    public void AddQuest(QuestBase newQuest){

        var questButton = Instantiate(questButtonPrefab, questHolder);

        questButton.GetComponent<QuestLogButtons>().SetQuest(newQuest);

    }
    
    private void Update(){

        if(Input.GetKeyDown(KeyCode.J)){

            questlogUI.SetActive(!questlogUI.activeSelf);

            if(questlogUI.activeSelf){
          
                if(lastDisplay == null) return;
                UpdateQuestUI(lastDisplay, lastDisplay.GetObjectiveList());
            }
        }
    }
}

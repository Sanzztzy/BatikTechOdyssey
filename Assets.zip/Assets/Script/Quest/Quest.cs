using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class Quest 
{   
    [SerializeField]
    private string title;

    [SerializeField]
    private string description;

    [SerializeField]
    private CollectObjective[] collectObjective;

    public QuestScript myQuestScript {get;set;}

    public string myTitle{
        
        get{
            return title;
        }
        set{
            title = value;
        }
    }
     public string myDescription{
        
        get{
            return description;
        }
        set{
            description = value;
        }
    }
     public CollectObjective[] myCollectObjective{
        
        get{
            return collectObjective;
        }
    }
}

[Serializable]
public abstract class Objective{

    public int currentAmount;
    [SerializeField] private int amount;
    [SerializeField] private string type;

    public int myAmount{
        
        get{
            return amount;
        }
    }
    public int myCurrentAmount{
        
        get{
            return currentAmount;
        }
        set{
            currentAmount = value;
        }
    }
    public string myType{
        
        get{
            return type;
        }
        
    }
}

[Serializable]
public class CollectObjective : Objective {

    public void UpdateItemCount(Item item, ItemContainer itemContainer){

        int itemCount = 0;

        if (myType.ToLower() == item.Name.ToLower()){

            foreach (ItemSlot itemSlot in itemContainer.slots){
                if (itemSlot != null && itemSlot.item != null && itemSlot.item.Name.ToLower() == myType.ToLower()){
                    itemCount += itemSlot.count;
                }
            }

            myCurrentAmount = itemCount;
            Debug.Log(myCurrentAmount);
        }
    }
}

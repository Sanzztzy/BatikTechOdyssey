using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class QuestManager : MonoBehaviour
{   

    public static QuestManager instance;

    private void Awake(){

        instance = this ;
    }

    public GameObject questUI;
    public Text questName;
    public Text questDescription;
    public Button questAccept;

    public QuestBase currentQuest {get; set;}
    public QuestTrigger currentQuestDialogue {get; set;}
    
    public void SetQuest(QuestBase quest){

        currentQuest = quest;
        questUI.SetActive(true);
        questName.text = quest.questName;
        questDescription.text = quest.questDescription;
    }
}

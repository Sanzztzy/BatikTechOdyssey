using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class QuestLogButtons : MonoBehaviour
{
    [HideInInspector]public QuestBase myQuest;
    public Text questName;
    public Image uncheckBox;
    public Sprite checkBox;

    public void SetQuest(QuestBase newQuest){

        myQuest = newQuest;
        questName.text = newQuest.questName;
    }

    public void OnPress(){

        QuestLogManager.instance.UpdateQuestUI(myQuest, myQuest.GetObjectiveList());
    }

    private void OnEnable(){

        if(myQuest.IsCompleted){

            uncheckBox.sprite = checkBox;
        }
    }
}
